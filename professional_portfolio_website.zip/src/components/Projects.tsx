import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export default function Projects() {
  const projects = useQuery(api.portfolio.getProjects) || [];

  // Sample projects based on resume
  const sampleProjects = [
    {
      _id: "1",
      title: "Operating System Deployment and Configuration Initiative",
      description: "Led a team in the installation and configuration of a new operating system for organizational computer systems. Researched and selected appropriate OS versions, created bootable USB drives, and facilitated deployment across multiple machines.",
      technologies: ["PowerShell", "Python", "Git", "Visual Studio Code", "System Administration"],
      featured: true,
    },
    {
      _id: "2",
      title: "Cybersecurity Risk Assessment Framework",
      description: "Developed comprehensive risk assessment procedures aligned with NIST and ISO 27001 frameworks. Implemented security policies and incident response plans for multiple client environments.",
      technologies: ["NIST Framework", "ISO 27001", "Risk Assessment", "Compliance", "Security Policies"],
      featured: true,
    },
    {
      _id: "3",
      title: "Penetration Testing & Security Analysis",
      description: "Conducted penetration testing engagements and phishing simulation campaigns. Analyzed security vulnerabilities and provided recommendations for security improvements.",
      technologies: ["Penetration Testing", "Nmap", "Wireshark", "Metasploit", "Burp Suite", "Security Analysis"],
      featured: true,
    },
  ];

  const displayProjects = projects.length > 0 ? projects : sampleProjects;

  return (
    <div className="section-container">
      <div className="container mx-auto px-6 py-20">
        <h2 className="section-title">Projects & Experience</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {displayProjects.map((project) => (
            <div key={project._id} className="project-card">
              <div className="project-image">
                {(project as any).imageUrl ? (
                  <img src={(project as any).imageUrl} alt={project.title} />
                ) : (
                  <div className="project-placeholder">
                    <svg className="w-12 h-12 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                    </svg>
                  </div>
                )}
              </div>
              
              <div className="project-content">
                <h3 className="project-title">{project.title}</h3>
                <p className="project-description">{project.description}</p>
                
                <div className="project-technologies">
                  {project.technologies.map((tech) => (
                    <span key={tech} className="tech-tag">{tech}</span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
