export default function Hero() {
  return (
    <div className="hero-section">
      <div className="container mx-auto px-6 py-20">
        <div className="text-center">
          <div className="hero-content">
            <h1 className="hero-title">
              Hi, I'm <span className="text-gradient">Adams Akindele</span>
            </h1>
            <p className="hero-subtitle">
              Cybersecurity Professional & Computer Technology Student
            </p>
            <p className="hero-description">
              Passionate about cybersecurity, risk assessment, and building secure digital solutions.
              Currently pursuing my Bachelor's in Computer Technology with hands-on experience in penetration testing and security operations.
            </p>
            
            <div className="hero-buttons">
              <button
                onClick={() => document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })}
                className="btn-primary"
              >
                View My Work
              </button>
              <button
                onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
                className="btn-secondary"
              >
                Get In Touch
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
