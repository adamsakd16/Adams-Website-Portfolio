export default function About() {
  const skills = [
    { name: "Network Security", level: 90 },
    { name: "Penetration Testing", level: 85 },
    { name: "Python", level: 80 },
    { name: "PowerShell", level: 85 },
    { name: "Linux Security", level: 80 },
    { name: "SIEM (Splunk, QRadar)", level: 75 },
    { name: "Vulnerability Assessment", level: 85 },
    { name: "Incident Response", level: 80 },
  ];

  const experiences = [
    {
      title: "Cyber Security and Privacy Intern",
      company: "Grant Thornton",
      period: "June 2025 – August 2025",
      description: "Assisted in conducting risk assessments and compliance assessments for clients across multiple industries aligned with NIST and ISO 27001 frameworks."
    },
    {
      title: "Cybersecurity Intern",
      company: "MasterCard",
      period: "June - August 2024",
      description: "Analyzed and identified security risks such as phishing and social engineering threats across business units."
    },
    {
      title: "Learning Ambassador",
      company: "Amazon Logistics",
      period: "January 2023 – February 2024",
      description: "Facilitated onboarding and offboarding processes, assisted in password resets and management, and provided training for new employees."
    },
  ];

  return (
    <div className="section-container">
      <div className="container mx-auto px-6 py-20">
        <h2 className="section-title">About Me</h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div className="space-y-6">
            <div className="card">
              <h3 className="text-2xl font-bold text-white mb-4">Technical Skills</h3>
              <div className="space-y-4">
                {skills.map((skill) => (
                  <div key={skill.name} className="skill-item">
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-300">{skill.name}</span>
                      <span className="text-blue-400">{skill.level}%</span>
                    </div>
                    <div className="skill-bar">
                      <div 
                        className="skill-progress"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="card">
              <h3 className="text-2xl font-bold text-white mb-4">Experience</h3>
              <div className="space-y-6">
                {experiences.map((exp, index) => (
                  <div key={index} className="experience-item">
                    <h4 className="text-xl font-semibold text-blue-400">{exp.title}</h4>
                    <p className="text-gray-300 font-medium">{exp.company}</p>
                    <p className="text-gray-400 text-sm mb-2">{exp.period}</p>
                    <p className="text-gray-300">{exp.description}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="card">
              <h3 className="text-2xl font-bold text-white mb-4">Education</h3>
              <div className="experience-item">
                <h4 className="text-xl font-semibold text-blue-400">Bachelor of Science: Computer Technology</h4>
                <p className="text-gray-300 font-medium">Bowie State University</p>
                <p className="text-gray-400 text-sm mb-2">Expected May 2026</p>
                <p className="text-gray-300">Focus on cybersecurity, network security, and system administration.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
