import { useState } from "react";

export default function QRCode() {
  const [showQR, setShowQR] = useState(false);
  
  // Generate QR code URL using a free service
  const portfolioUrl = window.location.origin;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(portfolioUrl)}`;

  return (
    <>
      <button
        onClick={() => setShowQR(!showQR)}
        className="qr-toggle"
        aria-label="Show QR Code"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-6l3-3h9l3 3v6zM7 8h10v4H7V8z" />
        </svg>
      </button>

      {showQR && (
        <div className="qr-modal">
          <div className="qr-content">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-white">Portfolio QR Code</h3>
              <button
                onClick={() => setShowQR(false)}
                className="text-gray-400 hover:text-white"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="text-center">
              <img
                src={qrCodeUrl}
                alt="Portfolio QR Code"
                className="mx-auto mb-4 rounded-lg"
              />
              <p className="text-gray-300 text-sm mb-4">
                Scan to visit this portfolio
              </p>
              <p className="text-blue-400 text-xs break-all">
                {portfolioUrl}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
