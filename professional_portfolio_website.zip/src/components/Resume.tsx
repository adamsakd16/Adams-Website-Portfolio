import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

export default function Resume() {
  const [isUploading, setIsUploading] = useState(false);
  const generateUploadUrl = useMutation(api.portfolio.generateResumeUploadUrl);
  const uploadResume = useMutation(api.portfolio.uploadResume);
  const resumeFile = useQuery(api.portfolio.getResumeFile);

  const handleResumeUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      // Generate upload URL
      const postUrl = await generateUploadUrl();
      
      // Upload file
      const result = await fetch(postUrl, {
        method: "POST",
        headers: { "Content-Type": file.type },
        body: file,
      });
      
      const json = await result.json();
      if (!result.ok) {
        throw new Error(`Upload failed: ${JSON.stringify(json)}`);
      }
      
      // Save file reference
      await uploadResume({ 
        storageId: json.storageId,
        filename: file.name,
        contentType: file.type
      });
      
      toast.success("Resume uploaded successfully!");
    } catch (error) {
      toast.error("Failed to upload resume. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  const downloadResume = async () => {
    if (resumeFile?.url) {
      const a = document.createElement('a');
      a.href = resumeFile.url;
      a.download = resumeFile.filename || 'Adams_Akindele_Resume.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else {
      // Fallback to text resume
      const resumeContent = `
ADAMS AKINDELE
Cybersecurity Professional & Computer Technology Student
Email: adamsakd16@gmail.com | Phone: (443)-251-8853

EDUCATION
Bowie State University | Bowie, MD                                                Expected May 2026
Bachelor of Science: Computer Technology
CERTIFICATIONS: CompTIA Security+: (in progress)

EXPERIENCES
Grant Thornton | Cyber Security and Privacy Intern | Philadelphia, PA          June 2025 – August 2025
• Assisted in conducting risk assessments and compliance assessments for clients across multiple industries align with NIST and ISO 27001 frameworks
• Supported the development and implementation of cybersecurity, policies, procedures, and incident response plans
• Collaborated with senior consultants on penetration testing engagements and phishing simulation campaigns
• Supported the implementation of GRC policies and risk controls

Amazon Logistics | Learning Ambassador | Hanover, MD                           January 2023 – February 2024
• Facilitated the onboarding and offboarding process in the Warehouse, assisted in password resets and management
• Provided training for new employees to ensure they were well prepared for their assigned task
• Collaborated with team members to meet productivity goals and ensure timely order fulfillment
• Participated in continuous improvement initiatives to optimize workflow and enhance productivity

MasterCard | Cyber security intern | Remote                                    June - August 2024
• Analyzed and identified security risk such as phishing and social engineering threats across business units
• Supported the implementation of targeted training programs and procedural controls to mitigate human related vulnerabilities
• Analyzed and identified which areas of the business needed more robust security training and implemented training courses and procedures for those teams

J.P Morgan & Chase cybersecurity virtual internship                            January 2024 – March 2024
• Focused on filtering out spam emails and analyzing extensive datasets of fraudulent financial transactions
• Examined security fundamentals and differentiated between various types of system attacks, enhancing understanding of cybersecurity in financial services
• Gained foundational knowledge of security operations, data protection and incident detection in a financial context

PROJECTS
Operating System Deployment and Configuration Initiative | PowerShell | Python | Git | Visual Studio Code
• Led a team in the installation and configuration of a new operating system for organization's computer systems
• Researched and selected the appropriate operating system version from the manufacturer's website, ensuring compatibility with hardware specifications
• Downloaded the OS and created a bootable USB drive, facilitating easy installation across multiple machines
• Resulted in a streamlined and efficient deployment of the new operating system, enhancing system reliability and performance organization wide

TECHNICAL SKILLS
Network Security | Vulnerability Assessment | Penetration Testing | Incident Response | SIEM (Splunk, QRadar) | Nmap | Wireshark | Metasploit | Burp Suite | Python | PowerShell | Linux Security | Windows Hardening | IAM | MFA | Active Directory Security | Cloud Security (AWS, Azure) | Firewall & IDS/IPS | MITRE ATT&CK | Compliance (NIST, ISO 27001)

ACTIVITIES & LEADERSHIP
Cybersecurity Club Member/President – participated in weekly CTFs and security workshops; led peer training sessions on basic offensive and defensive techniques
      `;

      const blob = new Blob([resumeContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Adams_Akindele_Resume.txt';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="section-container">
      <div className="container mx-auto px-6 py-20">
        <h2 className="section-title">Resume</h2>
        
        <div className="max-w-4xl mx-auto">
          <div className="card">
            <div className="resume-header">
              <h3 className="text-3xl font-bold text-white mb-2">Adams Akindele</h3>
              <p className="text-xl text-blue-400 mb-4">Cybersecurity Professional & Computer Technology Student</p>
              <div className="contact-info">
                <span>adamsakd16@gmail.com</span>
                <span>•</span>
                <span>(443) 251-8853</span>
              </div>
            </div>

            <div className="resume-section">
              <h4 className="resume-section-title">Professional Summary</h4>
              <p className="text-gray-300">
                Dedicated cybersecurity professional with hands-on experience in risk assessment, penetration testing, 
                and security operations. Currently pursuing Bachelor's in Computer Technology with proven track record 
                in implementing security frameworks and conducting vulnerability assessments across multiple industries.
              </p>
            </div>

            <div className="resume-section">
              <h4 className="resume-section-title">Technical Skills</h4>
              <div className="skills-grid">
                <div>
                  <h5 className="text-blue-400 font-semibold mb-2">Security</h5>
                  <p className="text-gray-300">Network Security, Penetration Testing, Vulnerability Assessment, Incident Response</p>
                </div>
                <div>
                  <h5 className="text-blue-400 font-semibold mb-2">Tools</h5>
                  <p className="text-gray-300">SIEM (Splunk, QRadar), Nmap, Wireshark, Metasploit, Burp Suite</p>
                </div>
                <div>
                  <h5 className="text-blue-400 font-semibold mb-2">Programming</h5>
                  <p className="text-gray-300">Python, PowerShell, Linux Security, Windows Hardening</p>
                </div>
                <div>
                  <h5 className="text-blue-400 font-semibold mb-2">Frameworks</h5>
                  <p className="text-gray-300">NIST, ISO 27001, MITRE ATT&CK, Cloud Security (AWS, Azure)</p>
                </div>
              </div>
            </div>

            <div className="resume-section">
              <h4 className="resume-section-title">Experience</h4>
              <div className="space-y-6">
                <div className="experience-item">
                  <div className="flex justify-between items-start mb-2">
                    <h5 className="text-xl font-semibold text-white">Cyber Security and Privacy Intern</h5>
                    <span className="text-gray-400">June 2025 – August 2025</span>
                  </div>
                  <p className="text-blue-400 mb-2">Grant Thornton | Philadelphia, PA</p>
                  <ul className="text-gray-300 space-y-1">
                    <li>• Assisted in conducting risk assessments and compliance assessments for clients across multiple industries</li>
                    <li>• Supported development and implementation of cybersecurity policies and incident response plans</li>
                    <li>• Collaborated with senior consultants on penetration testing engagements and phishing simulations</li>
                    <li>• Supported implementation of GRC policies and risk controls</li>
                  </ul>
                </div>

                <div className="experience-item">
                  <div className="flex justify-between items-start mb-2">
                    <h5 className="text-xl font-semibold text-white">Cybersecurity Intern</h5>
                    <span className="text-gray-400">June - August 2024</span>
                  </div>
                  <p className="text-blue-400 mb-2">MasterCard | Remote</p>
                  <ul className="text-gray-300 space-y-1">
                    <li>• Analyzed and identified security risks such as phishing and social engineering threats</li>
                    <li>• Supported implementation of targeted training programs to mitigate human-related vulnerabilities</li>
                    <li>• Identified areas needing robust security training and implemented training procedures</li>
                  </ul>
                </div>

                <div className="experience-item">
                  <div className="flex justify-between items-start mb-2">
                    <h5 className="text-xl font-semibold text-white">Learning Ambassador</h5>
                    <span className="text-gray-400">January 2023 – February 2024</span>
                  </div>
                  <p className="text-blue-400 mb-2">Amazon Logistics | Hanover, MD</p>
                  <ul className="text-gray-300 space-y-1">
                    <li>• Facilitated onboarding and offboarding processes, assisted in password management</li>
                    <li>• Provided comprehensive training for new employees</li>
                    <li>• Collaborated with teams to meet productivity goals and optimize workflows</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="resume-section">
              <h4 className="resume-section-title">Education</h4>
              <div className="experience-item">
                <div className="flex justify-between items-start mb-2">
                  <h5 className="text-xl font-semibold text-white">Bachelor of Science: Computer Technology</h5>
                  <span className="text-gray-400">Expected May 2026</span>
                </div>
                <p className="text-blue-400">Bowie State University | Bowie, MD</p>
                <p className="text-gray-300">Certifications: CompTIA Security+ (in progress)</p>
              </div>
            </div>

            <div className="resume-section">
              <h4 className="resume-section-title">Leadership & Activities</h4>
              <div className="experience-item">
                <h5 className="text-xl font-semibold text-white">Cybersecurity Club Member/President</h5>
                <p className="text-gray-300">Participated in weekly CTFs and security workshops; led peer training sessions on offensive and defensive techniques</p>
              </div>
            </div>

            <div className="text-center mt-8 space-y-4">
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <button
                  onClick={downloadResume}
                  className="btn-primary inline-flex items-center space-x-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <span>Download Resume</span>
                </button>
                
                <div className="relative">
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={handleResumeUpload}
                    disabled={isUploading}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <button
                    disabled={isUploading}
                    className="btn-secondary inline-flex items-center space-x-2"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <span>{isUploading ? "Uploading..." : "Upload New Resume"}</span>
                  </button>
                </div>
              </div>
              
              {resumeFile && (
                <p className="text-sm text-gray-400">
                  Current resume: {resumeFile.filename}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
