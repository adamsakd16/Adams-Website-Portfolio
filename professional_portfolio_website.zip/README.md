# Professional Portfolio Website

A modern, responsive portfolio website built with React, TypeScript, and Convex, featuring a dark theme with pixelated horizon scenery, interactive chatbot, QR code integration, and smooth animations.

## 🌟 Features

- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Dark Theme**: Unique dark theme with pixelated horizon background and dynamic colors
- **Interactive Chatbot**: AI-powered chatbot that answers FAQs about skills, experience, and projects
- **QR Code Integration**: Generate and display QR codes linking to the portfolio
- **Smooth Animations**: Beautiful transitions and animations throughout the site
- **Real-time Backend**: Powered by Convex for real-time data and messaging
- **Resume Download**: One-click resume download functionality
- **Contact Form**: Working contact form with data persistence
- **GitHub Integration**: Direct links to projects and repositories

## 🚀 Live Demo

[View Live Portfolio](https://your-portfolio-url.com)

## 📱 Sections

1. **Home**: Hero section with introduction and call-to-action buttons
2. **About**: Skills, experience, and education information
3. **Projects**: Showcase of projects with GitHub links and live demos
4. **Resume**: Professional resume with download option
5. **Contact**: Contact form and social links

## 🛠️ Technologies Used

- **Frontend**: React 19, TypeScript, Tailwind CSS
- **Backend**: Convex (real-time database and functions)
- **Authentication**: Convex Auth
- **Styling**: Custom CSS with Tailwind utilities
- **Icons**: Heroicons (SVG icons)
- **QR Code**: QR Server API
- **Animations**: CSS animations and transitions

## 🏃‍♂️ Running Locally

### Prerequisites

- Node.js (v18 or higher)
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/portfolio-website.git
   cd portfolio-website
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up Convex**
   ```bash
   npx convex dev
   ```
   Follow the prompts to create a new Convex project or link to an existing one.

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to `http://localhost:5173` to view the portfolio.

### Environment Setup

The project uses Convex for the backend, which handles:
- User authentication
- Chatbot message storage
- Contact form submissions
- Project data management

No additional environment variables are required for basic functionality.

## 🤖 Chatbot Setup

The chatbot is integrated and ready to use! It can answer questions about:

- Skills and technologies
- Work experience and background
- Projects and GitHub repositories
- Availability for work
- Tools and frameworks
- Education and learning
- Contact information

The chatbot uses predefined responses stored in the Convex backend and can be easily customized by modifying the `FAQ_RESPONSES` object in `convex/portfolio.ts`.

## 📋 Project Structure

```
portfolio-website/
├── src/
│   ├── components/
│   │   ├── Portfolio.tsx      # Main portfolio component
│   │   ├── Header.tsx         # Navigation header
│   │   ├── Hero.tsx          # Hero section
│   │   ├── About.tsx         # About section
│   │   ├── Projects.tsx      # Projects showcase
│   │   ├── Resume.tsx        # Resume section
│   │   ├── Contact.tsx       # Contact form
│   │   ├── Chatbot.tsx       # Interactive chatbot
│   │   └── QRCode.tsx        # QR code generator
│   ├── App.tsx               # Main app component
│   └── index.css             # Global styles
├── convex/
│   ├── schema.ts             # Database schema
│   ├── portfolio.ts          # Backend functions
│   └── auth.ts               # Authentication setup
├── public/                   # Static assets
└── README.md                 # This file
```

## 🎨 Customization

### Updating Personal Information

1. **Hero Section**: Edit `src/components/Hero.tsx`
2. **About Section**: Update skills and experience in `src/components/About.tsx`
3. **Resume**: Modify resume content in `src/components/Resume.tsx`
4. **Contact Info**: Update contact details in `src/components/Contact.tsx`

### Adding Projects

Projects can be added through the Convex database or by modifying the sample projects in `src/components/Projects.tsx`.

### Customizing the Chatbot

Edit the `FAQ_RESPONSES` object in `convex/portfolio.ts` to customize chatbot responses.

### Styling

The project uses Tailwind CSS with custom styles in `src/index.css`. The color scheme and animations can be customized by modifying the CSS variables and classes.

## 📱 Performance

- **Fast Loading**: Optimized for ≤2s load time on 4G connections
- **Responsive**: Mobile-first design approach
- **Smooth Animations**: Hardware-accelerated CSS animations
- **Real-time Updates**: Instant chatbot responses and form submissions

## 🔧 Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your repository to Vercel
3. Deploy with automatic Convex integration

### Other Platforms

The project can be deployed to any static hosting service that supports React applications.

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📞 Contact

- **Email**: your.email@example.com
- **GitHub**: [github.com/yourusername](https://github.com/yourusername)
- **Portfolio**: [your-portfolio-url.com](https://your-portfolio-url.com)

---

Built with ❤️ using React, TypeScript, and Convex
