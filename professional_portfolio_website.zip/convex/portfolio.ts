import { query, mutation } from "./_generated/server";
import { v } from "convex/values";

// Chatbot responses updated for Adams
const FAQ_RESPONSES = {
  skills: "I'm proficient in Network Security, Penetration Testing, Python, PowerShell, Linux Security, SIEM tools like Splunk and QRadar, and various cybersecurity frameworks including NIST and ISO 27001. I also have experience with vulnerability assessment tools like Nmap, Wireshark, Metasploit, and Burp Suite.",
  
  experience: "I have hands-on experience in cybersecurity through internships at Grant Thornton, MasterCard, and Amazon Logistics. I've conducted risk assessments, penetration testing, implemented security policies, and worked with compliance frameworks. I'm currently pursuing my Bachelor's in Computer Technology at Bowie State University.",
  
  projects: "I've led operating system deployment initiatives, developed cybersecurity risk assessment frameworks, and conducted penetration testing engagements. My projects focus on system security, vulnerability assessment, and implementing security best practices.",
  
  availability: "I'm currently pursuing my degree (expected May 2026) and am open to cybersecurity internships, part-time opportunities, and collaborations. I'm particularly interested in penetration testing, security analysis, and GRC roles.",
  
  tools: "I work with security tools including SIEM platforms (Splunk, QRadar), penetration testing tools (Nmap, Wireshark, Metasploit, Burp Suite), programming languages (Python, PowerShell), and compliance frameworks (NIST, ISO 27001, MITRE ATT&CK).",
  
  education: "I'm currently pursuing a Bachelor of Science in Computer Technology at Bowie State University (expected May 2026) and working on my CompTIA Security+ certification. I'm also active in the Cybersecurity Club where I participate in CTFs and lead training sessions.",
  
  contact: "You can reach me at adamsakd16@gmail.com or (443) 251-8853. I'm always happy to discuss cybersecurity opportunities, projects, or answer questions about my experience in security operations and risk assessment."
};

export const sendMessage = mutation({
  args: {
    content: v.string(),
    sessionId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // Store user message
    await ctx.db.insert("messages", {
      content: args.content,
      sender: "user",
      timestamp: Date.now(),
      sessionId: args.sessionId,
    });

    // Generate bot response
    const botResponse = generateBotResponse(args.content);
    
    // Store bot response
    await ctx.db.insert("messages", {
      content: botResponse,
      sender: "bot",
      timestamp: Date.now(),
      sessionId: args.sessionId,
    });

    return botResponse;
  },
});

export const getMessages = query({
  args: {
    sessionId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    if (!args.sessionId) return [];
    
    return await ctx.db
      .query("messages")
      .withIndex("by_session", (q) => q.eq("sessionId", args.sessionId))
      .order("asc")
      .collect();
  },
});

export const submitContact = mutation({
  args: {
    name: v.string(),
    email: v.string(),
    message: v.string(),
  },
  handler: async (ctx, args) => {
    await ctx.db.insert("contacts", {
      name: args.name,
      email: args.email,
      message: args.message,
      timestamp: Date.now(),
    });
    return { success: true };
  },
});

export const getProjects = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("projects").collect();
  },
});

export const addProject = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    technologies: v.array(v.string()),
    githubUrl: v.optional(v.string()),
    demoUrl: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    featured: v.boolean(),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("projects", args);
  },
});

export const generateResumeUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const uploadResume = mutation({
  args: {
    storageId: v.id("_storage"),
    filename: v.string(),
    contentType: v.string(),
  },
  handler: async (ctx, args) => {
    // Delete any existing resume
    const existingResume = await ctx.db.query("resumeFiles").first();
    if (existingResume) {
      await ctx.db.delete(existingResume._id);
    }

    // Insert new resume
    return await ctx.db.insert("resumeFiles", {
      storageId: args.storageId,
      filename: args.filename,
      contentType: args.contentType,
      uploadedAt: Date.now(),
    });
  },
});

export const getResumeFile = query({
  args: {},
  handler: async (ctx) => {
    const resumeFile = await ctx.db.query("resumeFiles").first();
    if (!resumeFile) return null;

    const url = await ctx.storage.getUrl(resumeFile.storageId);
    return {
      ...resumeFile,
      url,
    };
  },
});

function generateBotResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes("skill") || lowerMessage.includes("technology") || lowerMessage.includes("programming")) {
    return FAQ_RESPONSES.skills;
  }
  
  if (lowerMessage.includes("experience") || lowerMessage.includes("work") || lowerMessage.includes("background")) {
    return FAQ_RESPONSES.experience;
  }
  
  if (lowerMessage.includes("project") || lowerMessage.includes("github") || lowerMessage.includes("code")) {
    return FAQ_RESPONSES.projects;
  }
  
  if (lowerMessage.includes("available") || lowerMessage.includes("hire") || lowerMessage.includes("job")) {
    return FAQ_RESPONSES.availability;
  }
  
  if (lowerMessage.includes("tool") || lowerMessage.includes("software") || lowerMessage.includes("framework")) {
    return FAQ_RESPONSES.tools;
  }
  
  if (lowerMessage.includes("education") || lowerMessage.includes("learn") || lowerMessage.includes("study")) {
    return FAQ_RESPONSES.education;
  }
  
  if (lowerMessage.includes("contact") || lowerMessage.includes("reach") || lowerMessage.includes("email")) {
    return FAQ_RESPONSES.contact;
  }
  
  if (lowerMessage.includes("hello") || lowerMessage.includes("hi") || lowerMessage.includes("hey")) {
    return "Hello! I'm Adams Akindele, a cybersecurity professional and Computer Technology student. I'm here to answer questions about my skills, experience, projects, and availability. What would you like to know?";
  }
  
  return "I can help you learn more about my cybersecurity skills, experience, projects, tools, education, availability, or how to contact me. What would you like to know?";
}
