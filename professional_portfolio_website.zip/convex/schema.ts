import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  messages: defineTable({
    content: v.string(),
    sender: v.string(), // "user" or "bot"
    timestamp: v.number(),
    sessionId: v.optional(v.string()),
  }).index("by_session", ["sessionId"]),
  
  contacts: defineTable({
    name: v.string(),
    email: v.string(),
    message: v.string(),
    timestamp: v.number(),
  }),

  projects: defineTable({
    title: v.string(),
    description: v.string(),
    technologies: v.array(v.string()),
    githubUrl: v.optional(v.string()),
    demoUrl: v.optional(v.string()),
    imageUrl: v.optional(v.string()),
    featured: v.boolean(),
  }),

  resumeFiles: defineTable({
    storageId: v.id("_storage"),
    filename: v.string(),
    contentType: v.string(),
    uploadedAt: v.number(),
  }),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
